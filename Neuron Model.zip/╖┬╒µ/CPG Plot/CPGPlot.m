NetParam;

set(0, 'defaulttextinterpreter','latex') % 将图片的字体等等格式设置成latex样式，方便输入公式
set(0, 'defaultAxesTickLabelInterpreter','latex');
set(0, 'defaultLegendInterpreter','latex');

simout=sim('Network.slx');

t=simout.tout;
v1=simout.v1;
v2=simout.v2;
v3=simout.v3;
v4=simout.v4;


hs=tight_subplot(4,1,0.05);
% subplot(4,1,1)
axes(hs(1));
plot(t,v1,'LineWidth',3);
ylim([-1.5 1.0]);
grid on;
ylabel('$V_E^{HIP}$');

set(gca,'FontSize',22,'Fontname', 'Times New Roman','FontWeight','bold');

% legend('Membrane potential of Neuron 1','FontSize',24);

% subplot(4,1,2);
axes(hs(2));
plot(t,v2,'LineWidth',3);
ylim([-1.5 1.0]);

grid on;
ylabel('$V_F^{HIP}$');
set(gca,'FontSize',22,'Fontname', 'Times New Roman','FontWeight','bold');

% legend('Membrane potential of Neuron 2','Membrane potential of Neuron 3','FontSize',24);

% subplot(4,1,3);
axes(hs(3))
plot(t,v3,'LineWidth',3);
ylim([-1.5 1.0]);
grid on;
ylabel('$V_E^{Knee}$');

set(gca,'FontSize',22,'Fontname', 'Times New Roman','FontWeight','bold');

% subplot(4,1,4);
axes(hs(4))
plot(t,v4,'LineWidth',3);
ylim([-1.5 1.0]);
grid on;
xlabel('$t(s)$');
ylabel('$V_F^{Knee}$');

set(gca,'FontSize',22,'Fontname', 'Times New Roman','FontWeight','bold');


%%
Width=32;
Height=32;

filename='Figure7';

PlotToFileColorEPS(gcf,filename,Width,Height);