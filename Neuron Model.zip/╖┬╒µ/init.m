clc;
close all;
clear all;

addpath(genpath('CPG Net'),...
    genpath('CPG Plot'),...
    genpath('Freq'),...
    genpath('Reset'));

NetParam;

