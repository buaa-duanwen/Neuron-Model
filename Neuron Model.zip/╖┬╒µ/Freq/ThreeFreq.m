NetParam;

set(0, 'defaulttextinterpreter','latex') % 将图片的字体等等格式设置成latex样式，方便输入公式
set(0, 'defaultAxesTickLabelInterpreter','latex');
set(0, 'defaultLegendInterpreter','latex');

figure(1);

hs=tight_subplot(4,1,0.05);
% subplot(4,1,1)
axes(hs(4));

simout=sim('Network.slx');
t=simout.t;
v2=simout.v2;
plot(t,v2,'LineWidth',3);

hold on;

sigma_out=2.0;
simout=sim('Network.slx');
t=simout.t;
v2=simout.v2;
plot(t,v2,'LineWidth',3);

hold on;

sigma_out=1.0;
simout=sim('Network.slx');
t=simout.t;
v2=simout.v2;

plot(t,v2,'LineWidth',3);

ylim([-1.5 1.0]);

xlabel('$t(s)$');
ylabel('$V_F^{HIP}$');

legend('$\sigma_{out}=3.0$','$\sigma_{out}=2.0$','$\sigma_{out}=1.0$');

set(gca,'FontSize',22,'Fontname', 'Times New Roman','FontWeight','bold');

grid on;

%%
Width=32;
Height=32;

filename='Figure7';

PlotToFileColorEPS(gcf,filename,Width,Height);