NetParam;

set(0, 'defaulttextinterpreter','latex') % 将图片的字体等等格式设置成latex样式，方便输入公式
set(0, 'defaultAxesTickLabelInterpreter','latex');
set(0, 'defaultLegendInterpreter','latex');

sigma=1:0.05:3;
N=length(sigma);
f0=zeros(1,N);

Fs=200;
T=1/Fs;
L=4000;
t=(0:L-1)*T;
f = Fs*(0:L-1)/L;

for i=1:1:N
    sigma_out=sigma(i);
    simout=sim('Network.slx');
    S=simout.v1(1:L);
    P1=getP1(S);
    
%     plot(f,P1);
%     xlim([0 2]);
    
    [~,I]=max(P1);
    
    f0(i)=f(I);
end

plot(sigma,f0,'LineWidth',2);

grid on;


function P1=getP1(S)
L=length(S);

Y=fft(S);

P1=abs(Y).^2/L;


end