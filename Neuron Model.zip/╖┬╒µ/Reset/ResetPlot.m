NetParam;

set(0, 'defaulttextinterpreter','latex') % 将图片的字体等等格式设置成latex样式，方便输入公式
set(0, 'defaultAxesTickLabelInterpreter','latex');
set(0, 'defaultLegendInterpreter','latex');

figure(1);

hs=tight_subplot(4,1,0.05);
% subplot(4,1,1)
axes(hs(4));

flag=0;
simout=sim('Network.slx');
t=simout.t;
v1=simout.v2;
plot(t,v1,'LineWidth',3);

hold on;

flag=1;
t1=5-0.3*rand();
t2=t1+5-0.3*rand();
t3=t2+5-0.3*rand();
simout=sim('Network.slx');
t=simout.t;
v1=simout.v2;
plot(t,v1,'LineWidth',3);

hold on;

plot([t1+t_pulse t1+t_pulse],[-1.5 1.0],'linestyle','--','LineWidth',2);
plot([t2+t_pulse t2+t_pulse],[-1.5 1.0],'linestyle','--','LineWidth',2);
plot([t3+t_pulse t3+t_pulse],[-1.5 1.0],'linestyle','--','LineWidth',2);

% text(t1+t_pulse,1.0,'$Reset$','FontSize',18,'VerticalAlignment','bottom','HorizontalAlignment','center');
% text(t2+t_pulse,1.0,'$Reset$','FontSize',18,'VerticalAlignment','bottom','HorizontalAlignment','center');
% text(t3+t_pulse,1.0,'$Reset$','FontSize',18,'VerticalAlignment','bottom','HorizontalAlignment','center');

ylim([-1.5 1.0]);

xlabel('$t(s)$');
ylabel('$V_F^{HIP}$');

legend('Original Track','Reseted Track','Fontname', 'Times New Roman','Location','NorthWest');

set(gca,'FontSize',22,'Fontname', 'Times New Roman','FontWeight','bold');

grid on;

%%
Width=32;
Height=32;

filename='Figure7(d)';

PlotToFileColorEPS(gcf,filename,Width,Height);

