clc;
close all;
clear all;

%%
%膜电位方程参数
tau_m=0.05;
A_f=1.0;
sigma_f=0;

%快电流方程参数
tau_s=1.0;

sigma_in=3;
sigma_out=3;
E_s=0.0;

%互抑制电流参数
W=0.4;
upsilon=40;
theta=0.2;
E_post=-4;

%触发信号
t_pulse=0.3;
amplitude=0.8;

flag=0;
t0=0;
t1=5;
t2=10;
t3=15;




