%触发信号
t_pulse=10;
amplitude=2;